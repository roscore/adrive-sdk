"""ADrive linear actuator SDK.

    import adrive
    with adrive.connect() as act:
        act.enable()
        act.move_to(10.0)          # mm
        print(act.position())      # mm
"""
from ._core import (  # noqa: F401
    ADriveError, Actuator, FaultError, LinkError, NotFoundError, SafetyError,
    TimeoutError, UnsupportedError, build_info, connect, connect_all, scan,
)

__version__ = "0.1.0"
